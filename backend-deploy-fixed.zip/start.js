// This file ensures the application starts with the correct working directory
// so that it can find the node_modules folder.
require('./server/server.js'); 