// File: /pages/index.js

import Container from "@/components/Container";
import React from "react";
import Track from "./sections/Track";
import CallToActionSection from "@/components/CallToActionSection";
import ScrollOnSideSection from "@/components/ScrollOnSideSection";
import cors from 'cors';

app.use(cors({const index = () => {
  origin: true,    return (
  credentials: true,      <div className="main-container">
}));        
        <Container>
const index = () => {
    return (
      <div className="main-container">lToActionSection />
        
        <Container>div>
          <Track />
        </Container>
        <CallToActionSection />
        <ScrollOnSideSection />
      </div>s');
    );express();
  };
  use(cors({
  export default index;